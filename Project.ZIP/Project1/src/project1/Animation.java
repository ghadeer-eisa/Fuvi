/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.applet.Applet;
import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
public class Animation  extends JPanel implements Runnable{
    Thread runn;
    int x=300;
public Animation(){
    start();
    stop();
    run();
}
    
    public void start(){
        if(runn==null){
            runn=new Thread(this);
            runn.start();
        }
    }
    public void stop(){
        if (runn!=null){
            runn=null;
        }
    }
    
    @Override
    public void run() {
        while(true){
            repaint();
            try {
                Thread.sleep(30);
            } catch (InterruptedException ex) {
                Logger.getLogger(Animation.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawString("Welcome to Fuvi", x, 30);
        x--;
        if(x<-100)
            x=300;
    }
    
}

