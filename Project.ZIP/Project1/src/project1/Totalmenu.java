/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

/**
 *
 * @author amala
 */
public class Totalmenu {
    public static int Total_menue;

    public static int getTotal_menue() {
        return Total_menue;
    }

    public static void setTotal_menue(int Total_menue) {
        Totalmenu.Total_menue = Total_menue;
    }
}
