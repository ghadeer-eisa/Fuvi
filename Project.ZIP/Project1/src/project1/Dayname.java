/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

/**
 *
 * @author amala
 */
public class Dayname {
    public static String Day;
    public static String Timee;

    public static String getTimee() {
        return Timee;
    }

    public static void setTimee(String Timee) {
        Dayname.Timee = Timee;
    }

    public static String getDay() {
        return Day;
    }

    public static void setDay(String Day) {
        Dayname.Day = Day;
    }
}
