/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

/**
 *
 * @author amala
 */
public class Moviename {
    public static String mname; 

    public static String getMname() {
        return mname;
    }

    public static void setMname(String mname) {
        Moviename.mname = mname;
    }
}
